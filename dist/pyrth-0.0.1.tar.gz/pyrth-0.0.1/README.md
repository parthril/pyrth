echo "# pyrth" >> README.md
git init
git add *
git commit -m "first commit"
git remote add origin https://github.com/parthril/pyrth.git
git push -u origin master