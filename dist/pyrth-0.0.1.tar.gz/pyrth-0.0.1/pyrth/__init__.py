from pyrth.Dragonball import *
from pyrth.Naruto import *
